package com.company;

public interface Alimentavel {
    public void alimentar();
}
